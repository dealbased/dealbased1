
<div id="LayoutFooter">
<footer>
<div class="footer-top">
<section>
<ul>
<li class="footer-title">index.html Information</li>
<li><a href="index.htmlhelpdesk/policies/index.html-terms-of-use" rel="nofollow">Terms of Use</a></li>
<li><a href="index.htmlhelpdesk/policies/index.html-privacy-policy" rel="nofollow">Privacy Policy</a></li>
<li><a href="index.htmlhelpdesk/policies/" rel="nofollow">Posting Policy</a></li>
<li><a href="http://www.index.htmlforbusiness.ca" rel="nofollow">Advertise with Us</a></li>
<li><span class="ad-choice">AdChoice</span></li>
</ul>
</section>
<section>
<ul>
<li class="footer-title">DoDeal Support</li>
<li><a href="index.htmlhelpdesk/" rel="nofollow">Help Desk</a></li>
<li><a href="index.htmlhelpdesk/safety/safety-at-index.html" rel="nofollow">Online Safety Tips</a></li>

</ul>
</section>
<section>
<ul>
<li class="footer-title">index.html Autos</li>
<li><a id="DealerSignInLink" href="/t-dealer-registration.html" rel="nofollow">New Dealer Signup</a></li>
<li><a href="index.htmlhelpdesk/policies/why-use-index.html-autos" rel="nofollow">Dealer Help Pages</a></li>
<li><a href="http://index.htmlforbusiness.ca/autos/index.html-autos-blog/">Dealer Blog</a></li>
</ul>
</section>
<section>
<ul>
<li class="footer-title">Explore index.html</li>
<li><a href="index.htmlhelpdesk/basics/benefits-of-registering" rel="nofollow">index.html Member Benefits</a></li>
<li><a href="http://index.htmlblog.ca/about-us/" rel="nofollow">About index.html</a></li>
<li><a href="http://index.htmlblog.ca/heroes/" rel="nofollow">index.html Success Stories</a></li>
<li><a href="http://news.index.html.ca/news/">index.html News & Press Releases</a></li>
</ul>
</section>
<section class="last">
<ul>
<li class="footer-title">Frequently Asked Questions</li>
<li><a href="index.htmlhelpdesk/basics/benefits-of-promoting-ads" rel="nofollow">How do I get people to see my Ad?</a></li>
<li><a href="index.htmlhelpdesk/technical-issue/where-is-my-ad" rel="nofollow">Where is my index.html Ad? I can&#39;t find it.</a></li>
<li><a href="index.html" rel="nofollow">How can I change my Ad?</a></li>
<li><a href="index.html" rel="nofollow">How do I delete my Ad?</a></li>
</ul>
</section>
</div>

<div class="copyright"><br>
<p>Copyright &copy; 2015 RK International AG. All rights reserved.</p>
<p class="fine-print">Google, Google Play, YouTube and other marks are trademarks of Google Inc.</p>
</div>
</footer>
</div>
