<?php session_start();
    ?>
<!DOCTYPE html>
<!--[if IE 7]>
 <html class="ie ie7" lang="en-US">
 <![endif]-->
<!--[if IE 8]>
 <html class="ie ie8" lang="en-US">
 <![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US">
    <!--<![endif]-->
    <head>
        <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width">
                <!--Shortcut icon-->
                <link rel="profile" href="http://gmpg.org/xfn/11">
                    <link rel="pingback" href="http://azexo.com/kupon2/xmlrpc.php">
                        <title>Contact | Kupon</title>
                        <link rel="alternate" type="application/rss+xml" title="Kupon &raquo; Feed" href="http://azexo.com/kupon2/feed/" />
                        <link rel="alternate" type="application/rss+xml" title="Kupon &raquo; Comments Feed" href="http://azexo.com/kupon2/comments/feed/" />
                        <script type="text/javascript">
                            window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/azexo.com\/kupon2\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.3.1"}};
                            !function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
                            </script>
                        <style type="text/css">
                            img.wp-smiley,
                            img.emoji {
                                display: inline !important;
                                border: none !important;
                                box-shadow: none !important;
                                height: 1em !important;
                                width: 1em !important;
                                margin: 0 .07em !important;
                                vertical-align: -0.1em !important;
                                background: none !important;
                                padding: 0 !important;
                            }
                        </style>
                        <meta property="og:type" content="website"><meta property="og:description" content=""><meta property="og:title" content="index.html Canada"><link rel="stylesheet" type="text/css" href="css/master.css">
                            <link rel="stylesheet" href="css/example.css" href="example.css" type="text/css" media="screen" charset="utf-8" />
                            <link rel="stylesheet" href="css/example1.css"   type="text/css" media="screen" charset="utf-8" />

<link rel="stylesheet" type="text/css" href="css/page-checkout.css">

<link rel="stylesheet" type="text/css" href="css/sprites.css">
                            <link rel='stylesheet' id='contact-form-7-css'  href='css/styles.css?ver=4.3' type='text/css' media='all' />
                            <link rel='stylesheet' id='owl.carousel-css'  href='css/owl.carousel.min.css?ver=4.3.1' type='text/css' media='all' />
                            <link rel='stylesheet' id='flexslider-css'  href='css/flexslider.css?ver=4.3.1' type='text/css' media='all' />
                            <link rel='stylesheet' id='magnific-popup-css'  href='css/magnific-popup.css?ver=4.3.1' type='text/css' media='all' />
                            <link rel='stylesheet' id='js_composer_front-css'  href='css/js_composer.css?ver=4.6.1' type='text/css' media='all' />
                            <link rel='stylesheet' id='animate-css-css'  href='css/animate.css/animate.min.css?ver=4.3.1' type='text/css' media='all' />
                            <link rel='stylesheet' id='font-awesome-css'  href='css/font-awesome.min.css?ver=4.6.1' type='text/css' media='screen' />
                            <link rel='stylesheet' id='themify-icons-css'  href='css/themify-icons.css?ver=4.3.1' type='text/css' media='all' />
                            <link rel='stylesheet' id='azexo-style-css'  href='css/style.css?ver=4.3.1' type='text/css' media='all' />
                            <link rel='stylesheet' id='azexo-css'  href='css/azexo-07c6e42dd7.css' type='text/css' media='all' />
                            <link rel='stylesheet' id='select2-css'  href='css/select2.css?ver=4.3.1' type='text/css' media='all' />
                            <link rel='stylesheet' id='vc_linecons-css'  href='css/vc_linecons_icons.css?ver=4.6.1' type='text/css' media='screen' />
                            <script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/jquery.js?ver=1.11.3'></script>
                                <script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
                                <script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/azexo_vc_elements/js/azexo_vc.js?ver=4.3.1'></script>
                                <script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/azexo_vc_elements/js/scrollReveal.min.js?ver=4.3.1'></script>
                                <script type='text/javascript'>
                                /* <![CDATA[ */
                                var wc_add_to_cart_params = {"ajax_url":"\/kupon2\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kupon2\/contact\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"http:\/\/azexo.com\/kupon2\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
                                /* ]]> */
                                </script>
                                <script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=2.4.8'></script>
                                <script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=4.6.1'></script>
                                <script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/woocommerce-pdf-vouchers/includes/js/woo-vou-public.js?ver=2.4.5'></script>
                                <script type='text/javascript' src='css/js/jquery.fitvids.js?ver=1'></script>
                                <link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://azexo.com/kupon2/xmlrpc.php?rsd" />
                                <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://azexo.com/kupon2/wp-includes/wlwmanifest.xml" /> 
                                <meta name="generator" content="WordPress 4.3.1" />
                                <meta name="generator" content="WooCommerce 2.4.8" />
                                <link rel='canonical' href='http://azexo.com/kupon2/contact/' />
                                <link rel='shortlink' href='http://azexo.com/kupon2/?p=68' />
                                <style type="text/css">                    #header{
                                margin: 0 auto;
                                }                </style><!--CUSTOM STYLE--><style type="text/css"></style><!--/CUSTOM STYLE--><meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
                                <!--[if IE 8]><link rel="stylesheet" type="text/css" href="http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/css/vc-ie8.css" media="screen"><![endif]--><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>    </head>
                            
                            
                            
                            
                            <!-- Masthead -->
                            
                            

<?php
    
    include('Header.php');
    
    // should the html code before this php be deleted?
    
    ?>





                            


<body id="PageSelectPayment">


    <div id="PaymentMainContainer" class="layout-0 fixed-width bottom-space">
<h4>My order review</h4>

<hr>

<div class="layout-2">
<div class="col-2">
    
    <div class="container-info container-summary" id="PurchaseSummary">
    <h2>Your Order</h2>

    <dl>
    <dt><span class=""></span> Number of item(s)    </a></li>
</dt>
            <dd>


<span class="simpleCart_quantity"> 0 </span></li>


</dd>

<dt class="total"  >   Total Price:  <span class="simpleCart_total"> 0 </span> </dt>

<a href="Checkout.php" button class="button-task" type="submit" name="ccsubmit" id="ccsubmit">
Checkout</button></a>



 </div>
</div>
<div class="col-1">
<div class="container-forms">

<div class="container-info">
    

    <form method="post" action="https://payflowlink.paypal.com" id="creditCardForm" autocomplete="off" data-payment-type="CreditCard">
        
        
        <div class="simpleCart_items" >





</div>


<div class="  ">
<a href="index.php" button class="simpleCart_empty simpleCart_checkout2 button-task">Continue Shopping</button></a>
<a href='#' button class="simpleCart_empty button-task">Empty Cart</button></a>

</div>

<script src="javascripts/simpleCart.js" type="text/javascript" charset="utf-8"></script>

<!--Make a new cart instance with your paypal login email-->
<script type="text/javascript">
simpleCart = new cart("roudoouOu@mail.com");
</script>


</div>

</div>


</div>
</div>

</div>
<div id="LayoutFooter">
<footer>
<div class="footer-top">
<section>
<ul>
<li class="footer-title">index.html Information</li>
<li><a href="index.htmlhelpdesk/policies/index.html-terms-of-use" rel="nofollow">Terms of Use</a></li>
<li><a href="index.htmlhelpdesk/policies/index.html-privacy-policy" rel="nofollow">Privacy Policy</a></li>
<li><a href="index.htmlhelpdesk/policies/" rel="nofollow">Posting Policy</a></li>
<li><a href="http://www.index.htmlforbusiness.ca" rel="nofollow">Advertise with Us</a></li>
<li><span class="ad-choice">AdChoice</span></li>
</ul>
</section>
<section>
<ul>
<li class="footer-title">index.html Support</li>
<li><a href="index.htmlhelpdesk/" rel="nofollow">Help Desk</a></li>
<li><a href="index.htmlhelpdesk/safety/safety-at-index.html" rel="nofollow">Online Safety Tips</a></li>

</ul>
</section>
<section>
<ul>
<li class="footer-title">index.html Autos</li>
<li><a id="DealerSignInLink" href="/t-dealer-registration.html" rel="nofollow">New Dealer Signup</a></li>
<li><a href="index.htmlhelpdesk/policies/why-use-index.html-autos" rel="nofollow">Dealer Help Pages</a></li>
<li><a href="http://index.htmlforbusiness.ca/autos/index.html-autos-blog/">Dealer Blog</a></li>
</ul>
</section>
<section>
<ul>
<li class="footer-title">Explore index.html</li>
<li><a href="index.htmlhelpdesk/basics/benefits-of-registering" rel="nofollow">index.html Member Benefits</a></li>
<li><a href="http://index.htmlblog.ca/about-us/" rel="nofollow">About index.html</a></li>
<li><a href="http://index.htmlblog.ca/heroes/" rel="nofollow">index.html Success Stories</a></li>
<li><a href="http://news.index.html.ca/news/">index.html News & Press Releases</a></li>
</ul>
</section>
<section class="last">
<ul>
<li class="footer-title">Frequently Asked Questions</li>
<li><a href="index.htmlhelpdesk/basics/benefits-of-promoting-ads" rel="nofollow">How do I get people to see my Ad?</a></li>
<li><a href="index.htmlhelpdesk/technical-issue/where-is-my-ad" rel="nofollow">Where is my index.html Ad? I can&#39;t find it.</a></li>
<li><a href="index.html" rel="nofollow">How can I change my Ad?</a></li>
<li><a href="index.html" rel="nofollow">How do I delete my Ad?</a></li>
</ul>
</section>
</div>

<div class="copyright"><br>
<p>Copyright &copy; 2015 RK International AG. All rights reserved.</p>
<p class="fine-print">Google, Google Play, YouTube and other marks are trademarks of Google Inc.</p>
</div>
</footer>
</div>









</div><!-- #page -->

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
(w[c] = w[c] || []).push(function() {
try {
w.yaCounter30702498 = new Ya.Metrika({id:30702498,
webvisor:true,
clickmap:true,
trackLinks:true,
accurateTrackBounce:true});
} catch(e) { }
});

var n = d.getElementsByTagName("script")[0],
s = d.createElement("script"),
f = function () { n.parentNode.insertBefore(s, n); };
s.type = "text/javascript";
s.async = true;
s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

if (w.opera == "[object Opera]") {
d.addEventListener("DOMContentLoaded", f, false);
} else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/30702498" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter --><script type="text/javascript">                    jQuery(document).ready(function(){

});                </script><script type='text/javascript' src='css/js/azwoo.js?ver=1.12'></script>
<script type='text/javascript' src='css/js/jquery.countdown.min.js?ver=1.12'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_var = {"url":"http:\/\/azexo.com\/kupon2\/wp-admin\/admin-ajax.php","nonce":"d3c88ba798"};
/* ]]> */
</script>
<script type='text/javascript' src='css/post-like-system/js/post-like.min.js?ver=1.0'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/wc_deals/js/azwoo_deals.js?ver=4.3.1'></script>
<script type='text/javascript' src='js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/azexo.com\/kupon2\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ...","cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='js/scripts.js?ver=4.3'></script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/kupon2\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kupon2\/contact\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=2.4.8'></script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/kupon2\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kupon2\/contact\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=2.4.8'></script>
<script type='text/javascript' src='css/js/azexo.js?ver=1.12'></script>
<script type='text/javascript' src='css/js/jquery.sticky-kit.min.js?ver=1.12'></script>
<script type='text/javascript' src='css/js/imagesloaded.pkgd.min.js?ver=1.12'></script>
<script type='text/javascript' src='css/js/background-check.min.js?ver=1.12'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/js/js_composer_front.js?ver=4.6.1'></script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/select2/select2.min.js?ver=3.5.2'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/lib/bower/jquery-ui-tabs-rotate/jquery-ui-tabs-rotate.js?ver=4.6.1'></script>
</body>
</html>
