<?php
    session_start();
    ?>
<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US">
<!--<![endif]-->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width">
<!--Shortcut icon-->


<link rel="publisher" href="https://plus.google.com/+index.htmlCanada">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">



<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="http://azexo.com/kupon2/xmlrpc.php">
<title>Kupon | Just another WordPress site</title>
<link rel="alternate" type="application/rss+xml" title="Kupon &raquo; Feed" href="http://azexo.com/kupon2/feed/" />
<link rel="alternate" type="application/rss+xml" title="Kupon &raquo; Comments Feed" href="http://azexo.com/kupon2/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/azexo.com\/kupon2\/wp-includes\/js\/wp-emoji-release.min.js"}};
!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
display: inline !important;
border: none !important;
    box-shadow: none !important;
height: 1em !important;
width: 1em !important;
margin: 0 .07em !important;
    vertical-align: -0.1em !important;
background: none !important;
padding: 0 !important;
}
</style>
<meta property="og:type" content="website"><meta property="og:description" content=""><meta property="og:title" content="index.html Canada"><link rel="stylesheet" type="text/css" href="css/master.css">
<meta property="og:type" content="website"><meta property="og:description" content=""><meta property="og:title" content="index.html Canada"><link rel="stylesheet" type="text/css" href="css/example1.css">
<meta property="og:type" content="website"><meta property="og:description" content=""><meta property="og:title" content="index.html Canada"><link rel="stylesheet" type="text/css" href="css/example.css">


<link rel="stylesheet" type="text/css" href="css/page-checkout.css">
<link rel="stylesheet" type="text/css" href="css/sprites.css">
<link rel='stylesheet' id='contact-form-7-css'  href='css/styles.css?ver=4.3' type='text/css' media='all' />
<link rel='stylesheet' id='owl.carousel-css'  href='css/owl.carousel.min.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='flexslider-css'  href='css/flexslider.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='css/magnific-popup.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='css/js_composer.css?ver=4.6.1' type='text/css' media='all' />
<link rel='stylesheet' id='animate-css-css'  href='css/animate.css/animate.min.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='css/font-awesome.min.css?ver=4.6.1' type='text/css' media='screen' />
<link rel='stylesheet' id='themify-icons-css'  href='css/themify-icons.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='azexo-style-css'  href='css/style.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='azexo-css'  href='css/azexo-07c6e42dd7.css' type='text/css' media='all' />
<link rel='stylesheet' id='select2-css'  href='css/select2.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='vc_linecons-css'  href='css/vc_linecons_icons.css?ver=4.6.1' type='text/css' media='screen' />
<script type='text/javascript' src='jquery.js?ver=1.11.3'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/azexo_vc_elements/js/azexo_vc.js'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/azexo_vc_elements/js/scrollReveal.min.js'></script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=2.4.8'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/woocommerce-pdf-vouchers/includes/js/woo-vou-public.js?ver=2.4.5'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/themes/kupon/js/jquery.fitvids.js?ver=1'></script>
<script src='javascripts/simpleCart.js' type="text/javascript" charset="utf-8"></script>

<!--Make a new cart instance with your paypal login email-->
<script type="text/javascript">
simpleCart = new cart("brett@wojodesign.com");
</script>



<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://azexo.com/kupon2/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://azexo.com/kupon2/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 4.3.1" />
<meta name="generator" content="WooCommerce 2.4.8" />
<link rel='canonical' href='http://azexo.com/kupon2/' />
<link rel='shortlink' href='http://azexo.com/kupon2/' />
<style type="text/css">                    #header{
margin: 0 auto;
}                </style><!--CUSTOM STYLE--><style type="text/css"></style><!--/CUSTOM STYLE--><meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/css/vc-ie8.css" media="screen"><![endif]--><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>    </head>







<?php
    include('Header.php');
    // should the html code before this php be deleted?
    ?>
<?php
    session_start();
    ?>
<?php
    if(isset($_POST['title'])){
        
        $title = $_POST['title'];
        $body = $_POST['body'];
        $details = $_POST['details'];
        $old_price = $_POST['oldprice'];
        $new_price = $_POST['newprice'];
        $exp_date = $_POST['expirationdate'];
        $city = $_POST['city'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $categorie = $_POST['categorie'];
        
        
    }
    
    if(isset($_FILES['image'])){
        
        $errors = array();
        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_type = $_FILES['image']['type'];
        $file_ext = strtolower(end(explode('.',$_FILES['image']['name'])));
        
        $expensions = array("jpeg","jpg","png");
        
        if(in_array($file_ext, $expensions)==false){
            $errors[]="extension not allowed, please choose a JPEG or PNG file";
        }
        
        if($file_size>2097152){
            $errors[]="File size must be less than 2 MB";
            
        }
        
        if(empty($errors)==true){
            move_uploaded_file($file_tmp,"./images/".$file_name);
            $image_url = "./images/".$file_name;
            echo "success! Details updated successfully";
        }
        else{
            
            print_r($errors);
        }
        
        //Now the db part
        
        $servername = "localhost";
        $username = "intevzil_online";
        $password = "Qq03049835";
        $dbname = "intevzil_online";
        $conn = mysqli_connect($servername,$username,$password,$dbname);
        if(!$conn){
            
            die("Connection failed".mysqli_connect_error());
        }
        
        $sql = "INSERT INTO important (title, body, details, new_price, old_price, exp_date,categorie, city, address, phone, image_url)
        VALUES ('$title', '$body', '$details','$new_price', '$old_price', '$exp_date', '$categorie', '$city', '$address','$phone','$image_url')";
        
        if($conn->query($sql)===TRUE){
            echo "Details inserted in important table successfully";
        }  else{
            echo "ERROR:". $sql."<br>",$conn->error;
        }
        $conn->close();
    }
    ?>




<body id="PageSelectPayment">


<div id="PaymentMainContainer" class="layout-0 fixed-width bottom-space">
<h4>Post your add</h4>

<hr>

<div class="layout-2">
<div class="col-2">

<div class="container-info container-summary" id="PurchaseSummary">
<h2>Your Order</h2>

<dl>
</dt>
<dd>




</dd>


<a href="myCart.html" button class="button-task" type="submit" name="ccsubmit" id="ccsubmit">
Preview</button></a>



</div>
</div>
<div class="col-1">
<div class="container-forms">

<div class="container-info">


<form action="" method="POST" enctype="multipart/form-data">



<h2>Add description</span></h2>

<ul class="purchase-form">
<li>


<label for="title" class="add-asterisk">Title:</label>

<div class="form-section">
<input autocomplete="off" name="title" id="CreditCardNumber" maxlength="30" data-type="creditcard" req="" type="text">
</div>
</li>
<li>

<label for="description" class="add-asterisk">Description:</label>

<div class="form-section">
<input id="postad-title" name="body" req="req" type="text" value="" maxlength="64"><span class="field-message" data-for="pstad-descrptn"></span>
</div>

<li>
<label for="details" class="add-asterisk">Product Details:</label>

<div class="form-section">
<textarea id="pstad-descrptn" name="details" spellcheck="false" maxlength="61000" data-minlength="10" req="req"></textarea><span class="field-message" data-for="pstad-descrptn"></span>

</div>


</li>





<li>
<label for="oldprice" class="add-asterisk">Original price:</label>

<div class="form-section">
<input autocomplete="off" name="oldprice" id="PostalCode" req="" maxlength="6" data-type="number" type="text">
<span data-hasqtip="0" class="tooltip-trigger icon" data-content="CvvTooltip"></span>
<span class="field-message" data-for="SecurityCode"></span>


<label for="new_price" class="add-asterisk">Discounted price:</label>

<input autocomplete="off" name="newprice" id="PostalCode" req="" maxlength="6" data-type="number" type="text">
<span data-hasqtip="0" class="tooltip-trigger icon" data-content="CvvTooltip"></span>
<span class="field-message" data-for="SecurityCode"></span>


<li>
<label for="locationLevel0" class="add-asterisk">Categorie:</label>

<div class="form-section">
<select id="locationLevel0" name="categorie" req="req" class="locationSelector ">
<option value="travel">
Travel</option>
<option value="thingstodo">
Things to do</option>
<option value="electronics">
Electronics</option>
<option value="restaurants">
Restaurants</option>
<option value="fashion">
Fashion</option>
<option value="health">
Health and beauty</option>
<option value="products">
Products</option>
<option value="tickets">
Tickets</option>

</select>

<select id="locationLevel0" name="categorie" req="req" class="locationSelector ">
<option value="Coupon">
Coupon</option>
</select>


</div>



</span>

<li>
<h2>Contact information</span></h2>

<ul class="purchase-form">
<li>



<li>

<label for="locationLevel0" class="add-asterisk">City:</label>

<div class="form-section">
<select id="locationLevel0" name="city" req="req" class="locationSelector ">
<option value="Montreal">
Montreal</option>
<option value="Laval">
Laval</option>
</select>

</div>


<li>

<label for="description" class="add-asterisk">Address:</label>

<div class="form-section">
<input id="postad-title" name="address" req="req" type="text" value="" maxlength="64"><span class="field-message" data-for="pstad-descrptn"></span>
</div>


<li>

<label for="description" class="add-asterisk">Phone number:</label>

<div class="form-section">
<input autocomplete="off" name="phone" id="CreditCardNumber" maxlength="12" data-type="creditcard" req="" type="text">
</div>



</li>

<li>

<label for="title">Image:</label>

<div class="form-section">
<input name="image" id="body" req="" type="file">
</div>


</li>

<input type="submit"/>


</ul>
</form>
</div>



</div>

<div class="actions">
</div>

<div class="loading-overlay">
<div class="wrapper">
<div class="spinner"></div>
<p>Processing...</p>
</div>
</div>

</div>


</div>
</div>

</div>



</body>
<?php
    include('Footer.php');
    ?>

</html>