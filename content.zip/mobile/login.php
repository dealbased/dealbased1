<?php
    session_start();
    $emailaddress = $_POST ['emailaddress'];
    // th eline with the username got deleted? wait...the username variable you have to get it from the sql...all you have is the email address yeh i dont want username ... no username to log in client will use email .. its working ... normal ... its the firstname that we want to put on header. yes thats what i mean...you have to get the firstname from sql.... yeh so ?
    $password = $_POST ['password'];
    $_SESSION['systemMessage'] = '';
    $_SESSION['systemMessageSuccess']='';
    
    if ($emailaddress&&$password)
    {
        $connect = mysql_connect("localhost","credqglo_users","Qq03049835") or die ("Couldn't connect!");
        mysql_select_db("credqglo_users") or die ("Couldn't Find DB!");
        
        
        $query = mysql_query("SELECT * FROM users WHERE emailaddress = '".$emailaddress."' ");
        $numrows = mysql_num_rows($query);
        
        if ($numrows!=0)
        {
            while ($row = mysql_fetch_assoc($query))
            {
                $dbemailaddress = $row ['emailaddress'];
                $dbpassword = $row ['password'];
                $firstname = $row['firstname'];
            }
            
            if ($emailaddress == $dbemailaddress && md5($password) == $dbpassword)
            {
                $_SESSION['firstname'] = $firstname;
                $_SESSION['systemMessageSuccess'] = "Hi $firstname, you're Logged In! Enjoy our Daily deals :) ";
                $_SESSION ['emailaddress'] = $emailaddress;

            }
            
            else $_SESSION['systemMessage'] = "Bad Password";
        }
        else $_SESSION['systemMessage'] = "That Email Address is invalid";
        
    }
    else $_SESSION['systemMessage']="Please enter Email Address and Password";
    
    header("Location: RegisterLogin.php");
    


