<html>

<form action = 'login.php' method = 'POST'>
Username: <input type='text' name='emailaddress'><br>
Password: <input type='password' name='password'><br>
<input type='submit' value='Log in'><br>

</form>

<a href='RegisterLogin.html'> Click here </a> to Register

</html>