<link rel='stylesheet' id='font-awesome-css'  href='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=4.6.1' type='text/css' media='screen' />


<body class="       ">
<div id=" "><div id="status"></div></div>


<div id="page" class="hfeed site">






<body class="home page page-id-25 page-template-default wpb-js-composer js-comp-ver-4.6.1 vc_responsive">
<div id=""><div id="status"></div></div>




<header id="masthead" class="site-header clearfix">
<div id="secondary" class="sidebar-container " role="complementary">
<div class="sidebar-inner">
<div class="widget-area clearfix">
<div id="vc_widget-2" class="widget widget_vc_widget"><div class="scoped-style"><style type="text/css" data-type="vc_shortcodes-custom-css" scoped="">.vc_custom_1441702125378{margin-bottom: 0px !important;padding-top: 10px !important;padding-bottom: 10px !important;background-color: #303f9f !important;}.vc_custom_1441702200887{margin-bottom: 0px !important;padding-top: 25px !important;padding-bottom: 25px !important;background-color: #3f51b5 !important;}</style><div class="vc_row wpb_row vc_row-fluid vc_custom_1441702125378"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid container"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12 vc_hidden-sm vc_hidden-xs vc_col-md-6"><div class="wpb_wrapper">
    <div class="wpb_text_column wpb_content_element ">
    <div class="wpb_wrapper">
    <p>Have any questions? <strong>+080000000</strong> or contact@dealbase.ca</p>
    
    </div>
    </div> </div></div><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-xs-12 vc_col-md-6"><div class="wpb_wrapper"><div class="vc_wp_custommenu wpb_content_element"><div class="widget widget_nav_menu"><div class="menu-secondary-container"><ul id="menu-secondary" class="menu vc">
    
    
    
    <?php
    
    if ($_SESSION['firstname']!='')
    {
     echo 'Hi, '.$_SESSION['firstname'] . ' | <a href="logout.php">Logout</a>.';
    }
?>
    
    

    
    <li id="menu-item-289" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-289"><a href="post.php" class="menu-link">Submit deal</a></li>
    <li id="menu-item-286" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-206 current_page_item menu-item-286"><a href="RegisterLogin.php" class="menu-link">Login/Register</a></li>
    <li id="menu-item-287" class="menu-item menu-item-type-post_type menu-item-object-page cart menu-item-287"><a href="myCart.php" class="menu-link"><span class="fa fa-shopping-cart">
    
    </span>
    <span class="simpleCart_quantity"> 0 </span> My Cart</a></li>
    
    
    
    
    </ul></div></div></div>
    </div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1441702200887"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid container v-align-columns"><div class="row">
    
    <div class="wpb_column vc_column_container vc_col-sm-3"><div class="wpb_wrapper">
    <div class="wpb_single_image wpb_content_element responsive-align-center vc_align_left">
    <div class="wpb_wrapper">
    
    <a href="index.php" target="_self"><div class="vc_single_image-wrapper   vc_box_border_grey"><img width="180" height="54" src="Icons/dealbase.png" class="vc_single_image-img attachment-full" alt="logo white"></div></a>
    </div>
    </div> </div></div><div class="wpb_column vc_column_container vc_col-sm-9"><div class="wpb_wrapper">
    <form method="get" class="deal-searchform" action="index.php">
    <div class="searchform-wrapper">
    <div class="s-wrapper">
    </div>
    
    
    
    <form method="get" class="deal-searchform" action="index.php">
    <div class="searchform-wrapper">
    <div class="s-wrapper">
    <input type="text" name="s" value="" placeholder="Enter keywords here">
    </div>
    <div class="product-cat-wrapper">
    <select name="product_cat">
    
    <option value="">Select your Country</option>
    
    <option value="canada">Canada</option></select>
    </div>
    <div class="location-wrapper">
    <select name="location">
    <option value="">Select your location</option>
    <option value="montreal">Montreal</option><option value="toronto">Toronto</option><option value="vancouver">Vancouver</option><option value="alberta">Alberta</option><option value="laval">Laval</option>            </select>
    </div>
    <div class="submit">
    <input type="submit" value="Search deals">
    </div>
    <input type="hidden" name="post_type" value="product">
    </div>
    </form></div></div></div></div></div></div></div></div></div></div>            </div><!-- .widget-area -->
    </div><!-- .sidebar-inner -->
    </div><!-- #secondary -->
    
    <div class="header-main clearfix ">
    <div class="container">
    
    <div class="mobile-menu-button"><span><i class="fa fa-bars"></i></span></div>
    <nav class="site-navigation mobile-menu">
    
    <img alt="" src="icons/HomeIcon.jpg">
    
    <div class="menu-primary-container"><ul id="primary-menu-mobile" class="nav-menu"><li id="menu-item-563" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-563"><a href="index.php" class="menu-link"> </span>Home Page</a></li>
    
    <li id="menu-item-288" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-288"><a href="News.php" class="menu-link"> <span class="ti-marker-alt"></span>News</a></li>
    <li id="menu-item-291" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-291 mega"><a href="#" class="menu-link"> <span class="ti-layout-tab-v">
    
    </span>
    Mega menu</a><div class="page"><div class="scoped-style"><style type="text/css" data-type="vc_shortcodes-custom-css" scoped="">.vc_custom_1435816989630{margin-bottom: 0px !important;}</style><div class="vc_row wpb_row vc_row-fluid container vc_custom_1435816989630"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="wpb_wrapper">
    
    
    <div class="wpb_tour wpb_content_element" data-interval="0">
    <div class="wpb_wrapper wpb_tour_tabs_wrapper ui-tabs vc_clearfix">
    <ul class="wpb_tabs_nav ui-tabs-nav vc_clearfix"><li><a href="#tab-azexo-75937147">Travel</a></li><li><a href="#tab-azexo-45765582">Tickets</a></li><li><a href="#tab-azexo-35185536">Products</a></li></ul>
    
    
    <div id="tab-azexo-75937147" class="wpb_tab ui-tabs-panel wpb_ui-tabs-hide vc_clearfix">
    <div class="posts-list-wrapper  horizontal-list-3"><div class="posts-list latest-product   horizontal-list-3" data-posts-per-item="1" data-width="400" data-height="240" data-margin="0" data-full-width="" data-center="" data-loop=""><div class="latest-product post-139 product type-product status-publish has-post-thumbnail product_cat-products product_cat-travel product_tag-europe location-italy sale featured downloadable shipping-taxable purchasable product-type-simple product-cat-products product-cat-travel product-tag-europe instock">
    
    <div class="entry" itemscope="" itemtype="http://schema.org/Product">
    <meta itemprop="url" content="http://azexo.com/kupon2/product/us349-bermuda-this-summer-4-star-resort-w200-credit-2/">
    <div class="entry-thumbnail">
    
    <a href="http://azexo.com/kupon2/product/us349-bermuda-this-summer-4-star-resort-w200-credit-2/">
    
    
    
    
    
    <div id="tab-azexo-35185536" class="wpb_tab ui-tabs-panel wpb_ui-tabs-hide vc_clearfix">
    
    
    
    
    
    
    <div class="wpb_tour_next_prev_nav vc_clearfix"> <span class="wpb_prev_slide"><a href="#prev" title="Previous tab">Previous tab</a></span> <span class="wpb_next_slide"><a href="#next" title="Next tab">Next tab</a></span></div>
    </div>
    </div> </div></div></div></div>
    </div></div></div></div></li>
    <li id="menu-item-285" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-285"><a href="FAQ.php" class="menu-link"> <span class="ti-clipboard"></span>FAQ</a></li>
    <li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="Contact.php" class="menu-link"> <span class="ti-email"></span>Contact</a></li>
    </ul></div>                        </nav>
    <nav class="site-navigation primary-navigation">
    
    
    <div class="menu-primary-container"><ul id="primary-menu" class="nav-menu">
    
    
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-563">
    
    <a href="index.php" class="menu-link">
    <img src="Icons/HomeIcon.ico"> Home Page</a></li>
    
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-288"><a href="News.php" class="menu-link">  <img src="Icons/News.ico"> News</a></li>
    
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-291  ">
    
    <div class="page"><div class="scoped-style"><style type="text/css" data-type="vc_shortcodes-custom-css" scoped="">.vc_custom_1435816989630{margin-bottom: 0px !important;}</style>
    
    <div class="vc_row wpb_row vc_row-fluid container vc_custom_1435816989630">
    
    <div class="row">
    
    <div class="wpb_column vc_column_container vc_col-sm-12"><div class="wpb_wrapper">
    
    
    
    
    
    
    
    
    <div id="tab-azexo-68619023" class="wpb_tab ui-tabs-panel wpb_ui-tabs-hide vc_clearfix">
    <div class="posts-list-wrapper  horizontal-list-3"><div class="posts-list latest-product   horizontal-list-3" data-posts-per-item="1" data-width="400" data-height="240" data-margin="0" data-full-width="" data-center="" data-loop=""><div class="latest-product post-56 product type-product status-publish has-post-thumbnail product_cat-fun-staff product_cat-travel product_tag-travel sale featured downloadable shipping-taxable purchasable product-type-simple product-cat-fun-staff product-cat-travel product-tag-travel instock">
    
    </div>
    </div></div></div></div></div></div></div></div></li>
    
    
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="Contact.php" class="menu-link"> <img src="Icons/contact.ico"></span> Contact</a></li>
    </ul></div>                        </nav>
    </div>
    </div>
    
    </header>
