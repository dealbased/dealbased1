<?php session_start(); ?>
<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US">
<!--<![endif]-->
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width">
<!--Shortcut icon-->
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="http://azexo.com/kupon2/xmlrpc.php">
<title>Contact | Kupon</title>
<link rel="alternate" type="application/rss+xml" title="Kupon &raquo; Feed" href="http://azexo.com/kupon2/feed/" />
<link rel="alternate" type="application/rss+xml" title="Kupon &raquo; Comments Feed" href="http://azexo.com/kupon2/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/azexo.com\/kupon2\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.3.1"}};
!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
display: inline !important;
border: none !important;
    box-shadow: none !important;
height: 1em !important;
width: 1em !important;
margin: 0 .07em !important;
    vertical-align: -0.1em !important;
background: none !important;
padding: 0 !important;
}
</style>
<meta property="og:type" content="website"><meta property="og:description" content=""><meta property="og:title" content="index.html Canada"><link rel="stylesheet" type="text/css" href="css/master.css">
<link rel="stylesheet" href="css/example.css" href="example.css" type="text/css" media="screen" charset="utf-8" />
<link rel="stylesheet" href="css/example1.css"   type="text/css" media="screen" charset="utf-8" />

<link rel="stylesheet" type="text/css" href="css/page-checkout.css">

<link rel="stylesheet" type="text/css" href="css/sprites.css">
<link rel='stylesheet' id='contact-form-7-css'  href='css/styles.css?ver=4.3' type='text/css' media='all' />
<link rel='stylesheet' id='owl.carousel-css'  href='css/owl.carousel.min.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='flexslider-css'  href='css/flexslider.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='css/magnific-popup.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='css/js_composer.css?ver=4.6.1' type='text/css' media='all' />
<link rel='stylesheet' id='animate-css-css'  href='css/animate.css/animate.min.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='css/font-awesome.min.css?ver=4.6.1' type='text/css' media='screen' />
<link rel='stylesheet' id='themify-icons-css'  href='css/themify-icons.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='azexo-style-css'  href='css/style.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='azexo-css'  href='css/azexo-07c6e42dd7.css' type='text/css' media='all' />
<link rel='stylesheet' id='select2-css'  href='css/select2.css?ver=4.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='vc_linecons-css'  href='css/vc_linecons_icons.css?ver=4.6.1' type='text/css' media='screen' />
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/jquery.js?ver=1.11.3'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/azexo_vc_elements/js/azexo_vc.js?ver=4.3.1'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/azexo_vc_elements/js/scrollReveal.min.js?ver=4.3.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/kupon2\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kupon2\/contact\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"http:\/\/azexo.com\/kupon2\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=2.4.8'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=4.6.1'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/woocommerce-pdf-vouchers/includes/js/woo-vou-public.js?ver=2.4.5'></script>
<script type='text/javascript' src='css/js/jquery.fitvids.js?ver=1'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://azexo.com/kupon2/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://azexo.com/kupon2/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 4.3.1" />
<meta name="generator" content="WooCommerce 2.4.8" />
<link rel='canonical' href='http://azexo.com/kupon2/contact/' />
<link rel='shortlink' href='http://azexo.com/kupon2/?p=68' />
<style type="text/css">                    #header{
margin: 0 auto;
}                </style><!--CUSTOM STYLE--><style type="text/css"></style><!--/CUSTOM STYLE--><meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/css/vc-ie8.css" media="screen"><![endif]--><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>    </head>




<!-- Masthead -->
                                     <!-- Masthead -->


<?php
    
    include ('Header.php');
    
     ?> 






                                                        <body id="PageSelectPayment">


                                                        <div id="PaymentMainContainer" class="layout-0 fixed-width bottom-space">
                                                        <h4>Welcome to our Site</h4>

                                                        <hr>

                                                        <div class="layout-2">
                                                        <div class="col-2">

                                                        <div class="container-info container-summary" id="PurchaseSummary">
                                                        <h2>Why us?</h2>

                                                        <dl>
                                                        <dt><span class=""></span> We look forward to help you sav We look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you savWe look forward to help you sav   </a></li>
                                                        </dt>
                                                        <dd>




                                                        </dd>

                                                        
                                                        
                                                        
                                                        </div>
                                                        </div>
                                                        <div class="col-1">
                                                        <div class="container-forms">
                                                        
                                                        <div class="container-info">
                                                        
                                                        
                                                        <form action = 'login.php' method='post' >
                                                        
                                                        
                                                        
                                                        <h2>Log in </span></h2>
                                                            
                                                            
                                                            <?php
                                                            
                                                            echo '<p style="color: #CC0000">'.$_SESSION['systemMessage'].'</p>' ;
                                                            
                                                            $_SESSION['systemMessage']='';
                                                            
                                                            if ($_SESSION['systemMessageSuccess']!='')
                                                            {
                                                                echo '<p style="color: #00CC00">'.$_SESSION['systemMessageSuccess'].'</p>';

                                                             }
                                                            ?>
                                                        
  
                                                            
                                                        <ul class="purchase-form">
                                                        
                                                            
                                                       
                                                        <li>
                                                        <label for="firstname">Email Address:</label>
                                                        
                                                        <div class="form-section">
                                                        <input type='text' id='LastName' name='emailaddress'>                                                        </div>
                                                        </li>
                                                        
                                                        
                                                        <li>
                                                        <label for="lastname">Password:</label>
                                                        
                                                        <div class="form-section">
                                                        <input name="password" id="LastName" req="" type="password">
                                                        </div>
                                                        </li>
                                                        
                                                        
                                                        <li>
                                                        
                                                        
                                                        <p> <input type='submit' value='Log in'> </p>
                                                        
                                                        
                                                        </form>
                                                        
                                                        
                                                        
                                                        <form action = 'register.php' method='post' >
                                                        
                                                        
                                                        <label>&nbsp;</label>
                                                        
                                                        <h2>Register </span></h2>
                                                            
                                                            
                                                         <ul class="purchase-form">
                                                        
                                                        
                                                            <?php
                                                            
                                                            if ($_SESSION['systemMessageReg']!='')
                                                            {
                                                                echo '<p style="color: #CC0000">'.$_SESSION['systemMessageReg'] .'</p>';
                                                            } else if ($_SESSION['systemMessageRegSuccess'] != '')
                                                            {
                                                                echo '<p style="color: #00CC00">'.$_SESSION['systemMessageRegSuccess'] .'</p>';
                                                            }
                                                            
                                                            $_SESSION['systemMessageReg']='';
                                                            $_SESSION['systemMessageRegSuccess']='';                                                            ?>  

                                                        
                                                        <li>
                                                        <label for="firstname">First Name:</label>
                                                        
                                                        <div class="form-section">
                                                        <input name="firstname" id="FirstName" req="" type="text">
                                                        <span class="field-message" data-for="CardHolderName"></span>
                                                        </div>
                                                        </li>
                                                        
                                                        
                                                        <li>
                                                        <label for="lastname">Last Name:</label>
                                                        
                                                        <div class="form-section">
                                                        <input name="lastname" id="LastName" req="" type="text">
                                                        <span class="field-message" data-for="CardHolderName"></span>
                                                        </div>
                                                        </li>
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        <li>
                                                        <label for="emailaddress">Email Address:</label>
                                                        
                                                        <div class="form-section">
                                                        <input autocomplete="off" name="emailaddress" id="LastName" maxlength="50"   type="text">
                                                        </div>
                                                        </li>
                                                        
                                                        
                                                        
                                                        
                                                        <li>
                                                        <label for="Password">Password:</label>
                                                        
                                                        <div class="form-section">
                                                        <input autocomplete="off" name="password" id="LastName" maxlength="16"   type="password">
                                                        </div>
                                                        </li>
                                                        <li>
                                                        <label for="Password">Repeat Password:</label>
                                                        
                                                        <div class="form-section">
                                                        <input autocomplete="off" name="repeatpassword" id="LastName" maxlength="16"   type="password">
                                                        </div>
                                                        </li>
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        <li>
                                                        
                                                        
                                                        <p> <input class=" " type='submit' value='Register' name='submit'  </p>
                                                        
                                                        </div>
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        
                                                        </li>
                                                        </ul>
                                                        </form>
                                                        </div>
                                                        
                                                        
                                                        </div>
                                                        
                                                        
                                                        </div>
                                                        </div>
                                                        
                                                        </div>
                                                        
                                                        <div id="LayoutFooter">
                                                        <footer>
                                                        <div class="footer-top">
                                                        <section>
                                                        <ul>
                                                        <li class="footer-title">index.html Information</li>
                                                        <li><a href="index.htmlhelpdesk/policies/index.html-terms-of-use" rel="nofollow">Terms of Use</a></li>
                                                        <li><a href="index.htmlhelpdesk/policies/index.html-privacy-policy" rel="nofollow">Privacy Policy</a></li>
                                                        <li><a href="index.htmlhelpdesk/policies/" rel="nofollow">Posting Policy</a></li>
                                                        <li><a href="http://www.index.htmlforbusiness.ca" rel="nofollow">Advertise with Us</a></li>
                                                        <li><span class="ad-choice">AdChoice</span></li>
                                                        </ul>
                                                        </section>
                                                        <section>
                                                        <ul>
                                                        <li class="footer-title">index.html Support</li>
                                                        <li><a href="index.htmlhelpdesk/" rel="nofollow">Help Desk</a></li>
                                                        <li><a href="index.htmlhelpdesk/safety/safety-at-index.html" rel="nofollow">Online Safety Tips</a></li>
                                                        
                                                        </ul>
                                                        </section>
                                                        <section>
                                                        <ul>
                                                        <li class="footer-title">index.html Autos</li>
                                                        <li><a id="DealerSignInLink" href="/t-dealer-registration.html" rel="nofollow">New Dealer Signup</a></li>
                                                        <li><a href="index.htmlhelpdesk/policies/why-use-index.html-autos" rel="nofollow">Dealer Help Pages</a></li>
                                                        <li><a href="http://index.htmlforbusiness.ca/autos/index.html-autos-blog/">Dealer Blog</a></li>
                                                        </ul>
                                                        </section>
                                                        <section>
                                                        <ul>
                                                        <li class="footer-title">Explore index.html</li>
                                                        <li><a href="index.htmlhelpdesk/basics/benefits-of-registering" rel="nofollow">index.html Member Benefits</a></li>
                                                        <li><a href="http://index.htmlblog.ca/about-us/" rel="nofollow">About index.html</a></li>
                                                        <li><a href="http://index.htmlblog.ca/heroes/" rel="nofollow">index.html Success Stories</a></li>
                                                        <li><a href="http://news.index.html.ca/news/">index.html News & Press Releases</a></li>
                                                        </ul>
                                                        </section>
                                                        <section class="last">
                                                        <ul>
                                                        <li class="footer-title">Frequently Asked Questions</li>
                                                        <li><a href="index.htmlhelpdesk/basics/benefits-of-promoting-ads" rel="nofollow">How do I get people to see my Ad?</a></li>
                                                        <li><a href="index.htmlhelpdesk/technical-issue/where-is-my-ad" rel="nofollow">Where is my index.html Ad? I can&#39;t find it.</a></li>
                                                        <li><a href="index.html" rel="nofollow">How can I change my Ad?</a></li>
                                                        <li><a href="index.html" rel="nofollow">How do I delete my Ad?</a></li>
                                                        </ul>
                                                        </section>
                                                        </div>
                                                        
                                                        <div class="copyright"><br>
                                                        <p>Copyright &copy; 2015 RK International AG. All rights reserved.</p>
                                                        <p class="fine-print">Google, Google Play, YouTube and other marks are trademarks of Google Inc.</p>
                                                        </div>
                                                        </footer>
                                                        </div>
                                                        </body>
                                                        </html>