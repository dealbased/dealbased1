
<div id="LayoutFooter">
<footer>
<div class="footer-top">
<section>
<ul>
<li class="footer-title">Dealbase Information</li>
<li><a href="FAQ.php" rel="nofollow">Terms of Use</a></li>
<li><a href="FAQ.php" rel="nofollow">Privacy Policy</a></li>
<li><a href="FAQ.php" rel="nofollow">Posting Policy</a></li>
<li><a href="FAQ.php" rel="nofollow">Advertise with Us</a></li>
<li><span class="ad-choice">AdChoice</span></li>
</ul>
</section>
<section>
<ul>
<li class="footer-title">Dealbase Support</li>
<li><a href="FAQ.php" rel="nofollow">Help Desk</a></li>
<li><a href="FAQ.php" rel="nofollow">Online Safety Tips</a></li>

</ul>
</section>
<section>
<ul>
<li class="footer-title">index.html Autos</li>
<li><a id="DealerSignInLink" href="FAQ.php" rel="nofollow">New Dealer Signup</a></li>
<li><a href="FAQ.php" rel="nofollow">Dealer Help Pages</a></li>
<li><a href="FAQ.php">Dealer Blog</a></li>
</ul>
</section>
<section>
<ul>
<li class="footer-title">Explore index.html</li>
<li><a href="FAQ.php" rel="nofollow">Dealbase Member Benefits</a></li>
<li><a href="FAQ.php" rel="nofollow">About Dealbase.ca</a></li>
<li><a href="FAQ.php" rel="nofollow">Dealbase Success Stories</a></li>
<li><a href="FAQ.php">Dealbase News & Press Releases</a></li>
</ul>
</section>
<section class="last">
<ul>
<li class="footer-title">Frequently Asked Questions</li>
<li><a href="FAQ.php" rel="nofollow">How do I get people to see my Ad?</a></li>
<li><a href="FAQ.php" rel="nofollow">Where is my dealbase Ad? I can&#39;t find it.</a></li>
<li><a href="FAQ.php" rel="nofollow">How can I change my Ad?</a></li>
<li><a href="FAQ.php" rel="nofollow">How do I delete my Ad?</a></li>
</ul>
</section>
</div>

<div class="copyright"><br>
<p>Copyright &copy; 2015 RK International AG. All rights reserved.</p>
<p class="fine-print">Google, Google Play, YouTube and other marks are trademarks of Google Inc.</p>
</div>
</footer>
</div>
