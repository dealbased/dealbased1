<!DOCTYPE html>
<html>
<title>Contact Share Seller Deal</title>
<?php
    
    
    include('Header.php');
    ?>

<div id="main" class="site-main">

<div class="container active-sidebar">
<div id="primary" class="content-area">

<div class="wpb_text_column wpb_content_element ">
<div class="wpb_wrapper ">


</div>
 
<div id="woocommerce_product_categories-2" class="widget woocommerce widget_product_categories"><div class="widget-title"><h3>Categories</h3></div><ul class="product-categories">

<li class="cat-item cat-item-37"><a href="index.php?category=electronics"><img alt="" src="Icons/photo-camera2.svg"><span>Electronics</span></a> <span class="count">(<?php if (isset($categoryCountArray['electronics'])) echo $categoryCountArray['electronics']; else echo '0' ?>)</span></li>



<header class="page-header">
<h1 class="page-title">
How do I get people to see my Ad?</h1>
</header>

Posting an ad on Dealbase is hassle-free and takes only 5 to 15 minutes to submit the form.<br>
Step 1 Click on Submit Deal on the top right corner of the website.<br>
Step 2 Register and confirm your E-mail.<br>
Step 3 Submit your ad.<br><br>

Note: Make sure you fill all the fields required and review your information by clicking the preview button on the right of the page before submiting.

<br><br><br>

<header class="page-header">
<h1 class="page-title">
Where is my dealbase Ad? I can&#39;t find it.</h1>
</header>

After filling the easy ad submit form. Your dealbase ad will instantly and automatically be posted somewhere on the home-page. You can find your ad by surfing the website or you may also try to choose the categorie of your ad to easily locate it.
<br><br><br>



 <header class="page-header">
<h1 class="page-title">
How can I change my Ad?</h1>
</header>

For now editing your ad is impossible. But you may try to delete your add and post it again by fixing the errors that you made.
<br> for more information on how to delete your ad please read (how do i delete my ad ?) on the next line.

<br><br><br>


<header class="page-header">
<h1 class="page-title">
How do I delete my Ad?</h1>
</header>

Click on My profile, manage your ad and simply delete it.

<br><br><br>
 <header class="page-header">
<h1 class="page-title">
Dealbase Information</h1>
</header>

Dealbase is a new company that started in montreal during 2015 and getting ...
<br><br><br>



<header class="page-header">
<h1 class="page-title">
Privacy Policy </h1>
</header>

All your date will be protected and only seen to clients interested in having more information ... credit cards won't be saved in our database .. our website is 100% secure and has nothing to worry about ... in case of any problem placing or after buying somthing . you have the right to ask for a refund anytime even in 1 month.

<br><br><br>


<header class="page-header">
<h1 class="page-title">
Posting Policy</h1>
</header>

to post on dealbase you should have a business or working  and have the right to post for the copany ... 

<br><br><br>


<header class="page-header">
<h1 class="page-title">
Advertise with us</h1>
</header>

djsbkjhdsc bkjsdhcb  skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc


<br><br><br>


<header class="page-header">
<h1 class="page-title">
Help Desk</h1>
</header>

djsbkjhdsc bkjsdhcb  skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc


<br><br><br>



<header class="page-header">
<h1 class="page-title">
Online Safety tips</h1>
</header>

djsbkjhdsc bkjsdhcb  skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc


<br><br><br>


<header class="page-header">
<h1 class="page-title">
New Dealer Signup</h1>
</header>

djsbkjhdsc bkjsdhcb  skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc


<br><br><br>



<header class="page-header">
<h1 class="page-title">
Dealbase Member Benefits</h1>
</header>

djsbkjhdsc bkjsdhcb  skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc


<br><br><br>



<header class="page-header">
<h1 class="page-title">
Dealbase Success Stories </h1>
</header>

djsbkjhdsc bkjsdhcb  skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc


<br><br><br>



<header class="page-header">
<h1 class="page-title">
Dealbase News & Press Releases </h1>
</header>

djsbkjhdsc bkjsdhcb  skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc
djsbkjhdsc bkjsdhcb ksjdbchksdjbch skdjbch sdkcjbhskd cbhskdbchksdjchb skdjbchksdjbchsdcsdcsdc


<br><br><br>




</div><!-- .entry-content -->
</div><!-- #post -->
</div><!-- #content -->
</div><!-- #primary -->



 </div></div></div></div></div></div></div>            </div><!-- .widget-area -->
</div><!-- .sidebar-inner -->
</div><!-- #tertiary -->
</div>

</div><!-- #main -->











</div><!-- #page -->

<?php
    
    include('Footer.php');
    
    // should the html code before this php be deleted?
    ?>

</body>
</html>

