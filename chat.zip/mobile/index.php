<?php
    session_start();
    ?>

<!DOCTYPE html>
<!--[if IE 7]>
 <html class="ie ie7" lang="en-US">
 <![endif]-->
<!--[if IE 8]>
 <html class="ie ie8" lang="en-US">
 <![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US">
    <!--<![endif]-->
    <head>
        <meta charset="UTF-8">
  
            <meta name="viewport" content="width=device-width">
                <!--Shortcut icon-->
                <style>
                    body{font:12px/1.2 Verdana, sans-serif; padding:0 10px;}
                    a:link, a:visited{text-decoration:none; color:#416CE5; border-bottom:1px solid #416CE5;}
                    h2{font-size:13px; margin:15px 0 0 0;}
                    </style>
                <link rel="stylesheet" href="colorbox.css" />
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
                <script src="jquery.colorbox.js"></script>
                <script>
                    $(document).ready(function(){
                                      //Examples of how to assign the Colorbox event to elements
                                      $(".group1").colorbox({rel:'group1'});
                                      $(".group2").colorbox({rel:'group2', transition:"fade"});
                                      $(".group3").colorbox({rel:'group3', transition:"none", width:"75%", height:"75%"});
                                      $(".group4").colorbox({rel:'group4', slideshow:true});
                                      $(".ajax").colorbox();
                                      $(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390});
                                      $(".vimeo").colorbox({iframe:true, innerWidth:500, innerHeight:409});
                                      $(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
                                      $(".inline").colorbox({inline:true, width:"50%"});
                                      $(".callbacks").colorbox({
                                                               onOpen:function(){ alert('onOpen: colorbox is about to open'); },
                                                               onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
                                                               onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
                                                               onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
                                                               onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
                                                               });
                                      
                                      $('.non-retina').colorbox({rel:'group5', transition:'none'})
                                      $('.retina').colorbox({rel:'group5', transition:'none', retinaImage:true, retinaUrl:true});
                                      
                                      //Example of preserving a JavaScript event for inline calls.
                                      $("#click").click(function(){ 
                                                        $('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
                                                        return false;
                                                        });
                                      });
                    </script>
                        <meta property="og:type" content="website"><meta property="og:description" content=""><meta property="og:title" content="index.html Canada"><link rel="stylesheet" type="text/css" href="css/master.css">
                            
                            <link rel='stylesheet' id='contact-form-7-css'  href='http://azexo.com/kupon2/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.3' type='text/css' media='all' />
                                <link rel='stylesheet' id='owl.carousel-css'  href='http://azexo.com/kupon2/wp-content/themes/kupon/css/owl.carousel.min.css?ver=4.3.1' type='text/css' media='all' />
                                
                                
                                <link rel='stylesheet' id='vc_linecons-css'  href='css/vc_linecons_icons.css?ver=4.6.1' type='text/css' media='screen' />


                                 <link rel='stylesheet' id='js_composer_front-css'  href='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/css/js_composer.css?ver=4.6.1' type='text/css' media='all' />
                                 <link rel='stylesheet' id='font-awesome-css'  href='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=4.6.1' type='text/css' media='screen' />
                                <link rel='stylesheet' id='themify-icons-css'  href='http://azexo.com/kupon2/wp-content/themes/kupon/css/themify-icons.css?ver=4.3.1' type='text/css' media='all' />
                                <link rel='stylesheet' id='azexo-css'  href='http://azexo.com/kupon2/wp-content/uploads/wp-less/kupon/less/kupon2/azexo-07c6e42dd7.css' type='text/css' media='all' />
                                                                                                 <script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=2.4.8'></script>
                                 




                                
                                
            

<?php
        
                include('Header.php');
                
                // should the html code before this php be deleted?
                
                ?>




        
        <div class=" ">
        <div class=" ">
            <div class=" ">



<div class="   ">
                        
                        
                        <div class=" "><div class=" ">
                        
                        
                        
                        <h3>Newest deals</h3></div></div><div class="posts-list shop-product   horizontal-list-4 accent-2-color" data-posts-per-item="1" data-width="440" data-height="320" data-margin="0" data-full-width="" data-center="" data-loop="">




<!-- Product 1 -->



 
<div class="shop-product post-282 product type-product status-publish has-post-thumbnail product_cat-promo product_cat-travel product_tag-travel location-serbia sale shipping-taxable product-type-external product-cat-promo product-cat-travel product-tag-travel instock">

<div class="entry" itemscope itemtype="http://schema.org/Product">
                 <div class="entry-thumbnail">
              
              
                                            <div class="image " style='background-image: url("images/products/electronics/XboxOne.jpg"); height: 320px;' data-width="440" data-height="320">
                        </div>
                                    </a>        
                        <span class="purchased">1</span>        </div>
       
        <div class="entry-data">
        <div class="entry-header">
            <div class="entry-extra">
                                            </div>
                                            
                                            
                                            
                                            
                                            
                                <a class="entry-title group1  "
                                
                                 href="images/products/electronics/XboxMore.jpg" title="Xbox One">
                                <h3>Xbox One Limited Edition Halo 5: Guardians Bundle</h3>
                                <div data-role="popup" id="myPopup">
                                
                                
                                </div>

                     </a>
                    
                    
                    
                    
                                <div class="entry-meta">
                                        <div class="price-offer sale">
            <div class="discount">
                -20%            </div>
            <div class="regular-price">
                <span class="amount"><span class="currency">$</span>499.99</span>            </div>
            <div class="price">
                <span class="amount"><span class="currency">$</span>399.99</span>            </div>
        </div>
                    </div>
                    </div>
                                   
                                   
                                   <div class="entry-summary ">
                                   The Xbox One Limited Edition Halo 5: Guardians Bundle 1 includes Halo5 game, a controller ... To read more, please  
                                   
                                   
                                   <a class=" group1  "
                                   
                                   href="images/products/electronics/XboxMore.jpg" title="Xbox One"> <b>click here</b>.
                                   
                                   <div data-role="popup" id="myPopup"> </a>
                                   
                                   
                                   </div>

                 </div>
              
         <div class="entry-footer">
                    <div class="time-left">
            <div class="call-to-action">Hurry up! Time left:</div>
            <div class="time" data-time="2016/01/01 00:00:00">
                <div class="days"><span class="count">113</span><span class="title">d.</span></div>
                <div class="hours"><span class="count">1</span><span class="title">h.</span></div>
                <div class="minutes"><span class="count">33</span><span class="title">m.</span></div>
                <div class="seconds"><span class="count">59</span><span class="title">s.</span></div>
            </div>
        </div>
        <span class="add-to-cart"><a href="#" onclick="simpleCart.add('name=XboxOne Holo 5 bundle','price=399','image=images/products/electronics/XboxOne.jpg');return false;">Add to Cart</a></span>        </div>
                            </div>
</div>
</div>


                        
                        <!-- Product 2 -->
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <div class="shop-product post-282 product type-product status-publish has-post-thumbnail product_cat-promo product_cat-travel product_tag-travel location-serbia sale shipping-taxable product-type-external product-cat-promo product-cat-travel product-tag-travel instock">
                        
                        <div class="entry" itemscope itemtype="http://schema.org/Product">
                        <div class="entry-thumbnail">
                        
                        
                        <div class="image " style='background-image: url("images/2.png"); height: 320px;' data-width="440" data-height="320">
                        </div>
                        </a>
                        <span class="purchased">1</span>        </div>
                        
                        <div class="entry-data">
                        <div class="entry-header">
                        <div class="entry-extra">
                        </div>
                        
                        
                        
                        
                        
                        <a class="entry-title group1  "
                        
                        href="images/products/electronics/XboxMore.jpg" title="Xbox One">
                        
                        
                        <h3>Demo Object 2</h3>
                        
                        
                        <div data-role="popup" id="myPopup">
                        
                        
                        </div>
                        
                        </a>
                        
                        
                        
                        
                        <div class="entry-meta">
                        <div class="price-offer sale">
                        <div class="discount">
                        -20%            </div>
                        <div class="regular-price">
                        <span class="amount"><span class="currency">$</span>499.99</span>            </div>
                        <div class="price">
                        <span class="amount"><span class="currency">$</span>399.99</span>            </div>
                        </div>
                        </div>
                        </div>
                        
                        
                        <div class="entry-summary ">
                        The Xbox One Limited Edition Halo 5: Guardians Bundle 1 includes Halo5 game, a controller ... To read more, please
                        
                        
                        <a class=" group1  "
                        
                        href="images/products/electronics/XboxMore.jpg" title="Xbox One"> <b>click here</b>.
                        
                        <div data-role="popup" id="myPopup"> </a>
                        
                        
                        </div>
                        
                        </div>
                        
                        <div class="entry-footer">
                        <div class="time-left">
                        <div class="call-to-action">Hurry up! Time left:</div>
                        <div class="time" data-time="2016/01/01 00:00:00">
                        <div class="days"><span class="count">113</span><span class="title">d.</span></div>
                        <div class="hours"><span class="count">1</span><span class="title">h.</span></div>
                        <div class="minutes"><span class="count">33</span><span class="title">m.</span></div>
                        <div class="seconds"><span class="count">59</span><span class="title">s.</span></div>
                        </div>
                        </div>
                        <span class="add-to-cart"><a href="#" onclick="simpleCart.add('name=XboxOne Holo 5 bundle','price=399','image=images/products/electronics/XboxOne.jpg');return false;">Add to Cart</a></span>        </div>
                        </div>
                        </div>
                        </div>
                        



                        
                        <!-- Product 3 -->
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        <div class="shop-product post-282 product type-product status-publish has-post-thumbnail product_cat-promo product_cat-travel product_tag-travel location-serbia sale shipping-taxable product-type-external product-cat-promo product-cat-travel product-tag-travel instock">
                        
                        <div class="entry" itemscope itemtype="http://schema.org/Product">
                        <div class="entry-thumbnail">
                        
                        
                        <div class="image " style='background-image: url("images/3.png"); height: 320px;' data-width="440" data-height="320">
                        </div>
                        </a>
                        <span class="purchased">1</span>        </div>
                        
                        <div class="entry-data">
                        <div class="entry-header">
                        <div class="entry-extra">
                        </div>
                        
                        
                        
                        
                        
                        <a class="entry-title group1  "
                        
                        href="images/products/electronics/XboxMore.jpg" title="Xbox One">
                       
                        
                        <h3>Demo 3 Object deal</h3>
                        
                        <div data-role="popup" id="myPopup">
                        
                        
                        </div>
                        
                        </a>
                        
                        
                        
                        
                        <div class="entry-meta">
                        <div class="price-offer sale">
                        <div class="discount">
                        -20%            </div>
                        <div class="regular-price">
                        <span class="amount"><span class="currency">$</span>499.99</span>            </div>
                        <div class="price">
                        <span class="amount"><span class="currency">$</span>399.99</span>            </div>
                        </div>
                        </div>
                        </div>
                        
                        
                        <div class="entry-summary ">
                        The Xbox One Limited Edition Halo 5: Guardians Bundle 1 includes Halo5 game, a controller ... To read more, please
                        
                        
                        <a class=" group1  "
                        
                        href="images/products/electronics/3.png" title="Xbox One"> <b>click here</b>.
                        
                        <div data-role="popup" id="myPopup"> </a>
                        
                        
                        </div>
                        
                        </div>
                        
                        <div class="entry-footer">
                        <div class="time-left">
                        <div class="call-to-action">Hurry up! Time left:</div>
                        <div class="time" data-time="2016/01/01 00:00:00">
                        <div class="days"><span class="count">113</span><span class="title">d.</span></div>
                        <div class="hours"><span class="count">1</span><span class="title">h.</span></div>
                        <div class="minutes"><span class="count">33</span><span class="title">m.</span></div>
                        <div class="seconds"><span class="count">59</span><span class="title">s.</span></div>
                        </div>
                        </div>
                        <span class="add-to-cart"><a href="#" onclick="simpleCart.add('name=XboxOne Holo 5 bundle','price=399','image=images/products/electronics/XboxOne.jpg');return false;">Add to Cart</a></span>        </div>
                        </div>
                        </div>
                        </div>
                        




                        
                        
                        <!-- product 4 -->
                        
                        
                        
                        
                        
                        
                        <div class="shop-product post-282 product type-product status-publish has-post-thumbnail product_cat-promo product_cat-travel product_tag-travel location-serbia sale shipping-taxable product-type-external product-cat-promo product-cat-travel product-tag-travel instock">
                        
                        <div class="entry" itemscope itemtype="http://schema.org/Product">
                        <div class="entry-thumbnail">
                        
                        
                        <div class="image " style='background-image: url("images/4.png"); height: 320px;' data-width="440" data-height="320">
                        </div>
                        </a>
                        <span class="purchased">1</span>        </div>
                        
                        <div class="entry-data">
                        <div class="entry-header">
                        <div class="entry-extra">
                        </div>
                        
                        
                        
                        
                        
                        <a class="entry-title group1  "
                        
                        href="images/4.png" title="Xbox One">
                        
                        
                        <h3>Demo 4 Object deal</h3>
                        
                        <div data-role="popup" id="myPopup">
                        
                        
                        </div>
                        
                        </a>
                        
                        
                        
                        
                        <div class="entry-meta">
                        <div class="price-offer sale">
                        <div class="discount">
                        -20%            </div>
                        <div class="regular-price">
                        <span class="amount"><span class="currency">$</span>499.99</span>            </div>
                        <div class="price">
                        <span class="amount"><span class="currency">$</span>399.99</span>            </div>
                        </div>
                        </div>
                        </div>
                        
                        
                        <div class="entry-summary ">
                        The Xbox One Limited Edition Halo 5: Guardians Bundle 1 includes Halo5 game, a controller ... To read more, please
                        
                        
                        <a class=" group1  "
                        
                        href="images/4.png" title="Xbox One"> <b>click here</b>.
                        
                        <div data-role="popup" id="myPopup"> </a>
                        
                        
                        </div>
                        
                        </div>
                        
                        <div class="entry-footer">
                        <div class="time-left">
                        <div class="call-to-action">Hurry up! Time left:</div>
                        <div class="time" data-time="2016/01/01 00:00:00">
                        <div class="days"><span class="count">113</span><span class="title">d.</span></div>
                        <div class="hours"><span class="count">1</span><span class="title">h.</span></div>
                        <div class="minutes"><span class="count">33</span><span class="title">m.</span></div>
                        <div class="seconds"><span class="count">59</span><span class="title">s.</span></div>
                        </div>
                        </div>
                        <span class="add-to-cart"><a href="#" onclick="simpleCart.add('name=XboxOne Holo 5 bundle','price=399','image=images/products/electronics/XboxOne.jpg');return false;">Add to Cart</a></span>        </div>
                        </div>
                        </div>
                        </div>
                        




                        
                        
                        
                        
                        
                        <!-- product 5 -->
                        
                        
                        
                        
                        
                        
                        <div class="shop-product post-282 product type-product status-publish has-post-thumbnail product_cat-promo product_cat-travel product_tag-travel location-serbia sale shipping-taxable product-type-external product-cat-promo product-cat-travel product-tag-travel instock">
                        
                        <div class="entry" itemscope itemtype="http://schema.org/Product">
                        <div class="entry-thumbnail">
                        
                        
                        <div class="image " style='background-image: url("images/5.png"); height: 320px;' data-width="440" data-height="320">
                        </div>
                        </a>
                        <span class="purchased">1</span>        </div>
                        
                        <div class="entry-data">
                        <div class="entry-header">
                        <div class="entry-extra">
                        </div>
                        
                        
                        
                        
                        
                        <a class="entry-title group1  "
                        
                        href="images/5.png" title="Xbox One">
                        
                        
                        <h3>Demo 5 Object deal</h3>
                        
                        <div data-role="popup" id="myPopup">
                        
                        
                        </div>
                        
                        </a>
                        
                        
                        
                        
                        <div class="entry-meta">
                        <div class="price-offer sale">
                        <div class="discount">
                        -20%            </div>
                        <div class="regular-price">
                        <span class="amount"><span class="currency">$</span>499.99</span>            </div>
                        <div class="price">
                        <span class="amount"><span class="currency">$</span>399.99</span>            </div>
                        </div>
                        </div>
                        </div>
                        
                        
                        <div class="entry-summary ">
                        The Xbox One Limited Edition Halo 5: Guardians Bundle 1 includes Halo5 game, a controller ... To read more, please
                        
                        
                        <a class=" group1  "
                        
                        href="images/5.png" title="Xbox One"> <b>click here</b>.
                        
                        <div data-role="popup" id="myPopup"> </a>
                        
                        
                        </div>
                        
                        </div>
                        
                        <div class="entry-footer">
                        <div class="time-left">
                        <div class="call-to-action">Hurry up! Time left:</div>
                        <div class="time" data-time="2016/01/01 00:00:00">
                        <div class="days"><span class="count">113</span><span class="title">d.</span></div>
                        <div class="hours"><span class="count">1</span><span class="title">h.</span></div>
                        <div class="minutes"><span class="count">33</span><span class="title">m.</span></div>
                        <div class="seconds"><span class="count">59</span><span class="title">s.</span></div>
                        </div>
                        </div>
                        <span class="add-to-cart"><a href="#" onclick="simpleCart.add('name=XboxOne Holo 5 bundle','price=399','image=images/5.png');return false;">Add to Cart</a></span>        </div>
                        </div>
                        </div>
                        </div>


</div></div></div></div></div></div></div></div></div></div>
                                    </div><!-- .entry-content -->
            </div><!-- #post -->
                        </div><!-- #content -->
</div><!-- #primary -->


                        
                        
                        
                        


<!-- Yandex.Metrika counter -->




<!-- timer -->


<script src="javascripts/simpleCart.js" type="text/javascript" charset="utf-8"></script>

<!--Make a new cart instance with your paypal login email-->
<script type="text/javascript">
simpleCart = new cart("brett@wojodesign.com");
</script>



<!-- timer -->
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/themes/kupon/js/jquery.countdown.min.js?ver=1.12'></script>

<script type='text/javascript'>

/* <![CDATA[ */
var ajax_var = {"url":"http:\/\/azexo.com\/kupon2\/wp-admin\/admin-ajax.php","nonce":"e091c26672"};
/* ]]> */
</script>

<script type='text/javascript' src='javascripts/redirect.js'></script>




<!-- slide -->
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/themes/kupon/js/owl.carousel.min.js?ver=1.12'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/themes/kupon/js/imagesloaded.pkgd.min.js?ver=1.12'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/themes/kupon/js/azexo.js?ver=1.12'></script>

<!-- slide -->

</body>
</html>
 