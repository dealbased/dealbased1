<link rel='stylesheet' id='font-awesome-css'  href='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=4.6.1' type='text/css' media='screen' />

<body class="       ">
<div id=" "><div id="status"></div></div>


<div id="page" class="hfeed site">






<body class="home page page-id-25 page-template-default wpb-js-composer js-comp-ver-4.6.1 vc_responsive">
<div id=""><div id="status"></div></div>




<header id="masthead" class="site-header clearfix">
<div id="secondary" class="sidebar-container " role="complementary">
<div class="sidebar-inner">
<div class="widget-area clearfix">
<div id="vc_widget-2" class="widget widget_vc_widget"><div class="scoped-style"><style type="text/css" data-type="vc_shortcodes-custom-css" scoped="">.vc_custom_1441702125378{margin-bottom: 0px !important;padding-top: 10px !important;padding-bottom: 10px !important;background-color: #303f9f !important;}.vc_custom_1441702200887{margin-bottom: 0px !important;padding-top: 25px !important;padding-bottom: 25px !important;background-color: #3f51b5 !important;}</style><div class="vc_row wpb_row vc_row-fluid vc_custom_1441702125378"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid container"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12 vc_hidden-sm vc_hidden-xs vc_col-md-6"><div class="wpb_wrapper">
    <div class="wpb_text_column wpb_content_element ">
    <div class="wpb_wrapper">
    <p>Have any questions? <strong>+080 124 880</strong> or mail@pamukovic.com</p>
    
    </div>
    </div> </div></div><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-xs-12 vc_col-md-6"><div class="wpb_wrapper"><div class="vc_wp_custommenu wpb_content_element"><div class="widget widget_nav_menu"><div class="menu-secondary-container"><ul id="menu-secondary" class="menu vc">
    
    
    
    <?php
    
    if ($_SESSION['firstname']!='')
    {
     echo 'Hi, '.$_SESSION['firstname'] . ' | <a href="logout.php">Logout</a>.';
    }
?>
    
    

    
    <li id="menu-item-289" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-289"><a href="Contact.php" class="menu-link">Submit deal</a></li>
    <li id="menu-item-286" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-206 current_page_item menu-item-286"><a href="RegisterLogin.php" class="menu-link">Login/Register</a></li>
    <li id="menu-item-287" class="menu-item menu-item-type-post_type menu-item-object-page cart menu-item-287"><a href="myCart.php" class="menu-link"><span class="fa fa-shopping-cart">
    
    </span>
    <span class="simpleCart_quantity"> 0 </span> My Cart</a></li>
    
    
    
    
    </ul></div></div></div>
    </div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1441702200887"><div class="row"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid container v-align-columns"><div class="row">
    
    <div class="wpb_column vc_column_container vc_col-sm-3"><div class="wpb_wrapper">
    <div class="wpb_single_image wpb_content_element responsive-align-center vc_align_left">
    <div class="wpb_wrapper">
    
    <a href="index.php" target="_self"><div class="vc_single_image-wrapper   vc_box_border_grey"><img width="180" height="54" src="http://azexo.com/kupon2/wp-content/uploads/2015/07/logo-white.png" class="vc_single_image-img attachment-full" alt="logo white"></div></a>
    </div>
    </div> </div></div><div class="wpb_column vc_column_container vc_col-sm-9"><div class="wpb_wrapper">
    
    
    
    <form method="post" class="deal-searchform" action="index.php">
    <div class="searchform-wrapper">
    <div class="s-wrapper">
    </div>
    
    
    
    <form method="post" class="deal-searchform" action="index.php" >
    <div class="searchform-wrapper">
    <div class="s-wrapper">
    <input type="text" name="s" value="" placeholder="Enter keywords here">
    </div>
    <div class="product-cat-wrapper">
    <select name="product_cat">
    
    <option value="">Select your Country</option>
    
    <option value="electronics">Canada</option><option value="Canada">Europe</option><option value="Europe" <="" option=""></option></select>
    </div>
    <div class="location-wrapper">
    <select name="location">
    <option value="">Select your location</option>
    <option value="austria">Austria</option><option value="croatia">Croatia</option><option value="italy">Italy</option><option value="monte-negro">Monte Negro</option><option value="serbia">Serbia</option>            </select>
    </div>
    <div class="submit">
    <input type="submit" value="Search deals">
    </div>
    <input type="hidden" name="post_type" value="product">
    </div>
    </form></div></div></div></div></div></div></div></div></div></div>            </div><!-- .widget-area -->
    </div><!-- .sidebar-inner -->
    </div><!-- #secondary -->
    
    <div class="header-main clearfix ">
    <div class="container">
    
 </div></li>
    
    
  </div></li>
    
    
     </ul></div>                        </nav>
    </div>
    </div>
    
    </header>
