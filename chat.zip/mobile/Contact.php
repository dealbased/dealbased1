
<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US">
    <!--<![endif]-->
    <head>
                <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width">
        <!--Shortcut icon-->
                <link rel="profile" href="http://gmpg.org/xfn/11">
        <link rel="pingback" href="http://azexo.com/kupon2/xmlrpc.php">
        <title>Contact | Kupon</title>
<link rel="alternate" type="application/rss+xml" title="Kupon &raquo; Feed" href="http://azexo.com/kupon2/feed/" />
<link rel="alternate" type="application/rss+xml" title="Kupon &raquo; Comments Feed" href="http://azexo.com/kupon2/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"http:\/\/s.w.org\/images\/core\/emoji\/72x72\/","ext":".png","source":{"concatemoji":"http:\/\/azexo.com\/kupon2\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.3.1"}};
			!function(a,b,c){function d(a){var c=b.createElement("canvas"),d=c.getContext&&c.getContext("2d");return d&&d.fillText?(d.textBaseline="top",d.font="600 32px Arial","flag"===a?(d.fillText(String.fromCharCode(55356,56812,55356,56807),0,0),c.toDataURL().length>3e3):(d.fillText(String.fromCharCode(55357,56835),0,0),0!==d.getImageData(16,16,1,1).data[0])):!1}function e(a){var c=b.createElement("script");c.src=a,c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g;c.supports={simple:d("simple"),flag:d("flag")},c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.simple&&c.supports.flag||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
        <meta property="og:type" content="website"><meta property="og:description" content=""><meta property="og:title" content="index.html Canada"><link rel="stylesheet" type="text/css" href="css/master.css">
 
        <link rel='stylesheet' id='contact-form-7-css'  href='css/styles.css?ver=4.3' type='text/css' media='all' />
        <link rel='stylesheet' id='owl.carousel-css'  href='css/owl.carousel.min.css?ver=4.3.1' type='text/css' media='all' />
        <link rel='stylesheet' id='flexslider-css'  href='css/flexslider.css?ver=4.3.1' type='text/css' media='all' />
        <link rel='stylesheet' id='magnific-popup-css'  href='css/magnific-popup.css?ver=4.3.1' type='text/css' media='all' />
        <link rel='stylesheet' id='js_composer_front-css'  href='css/js_composer.css?ver=4.6.1' type='text/css' media='all' />
        <link rel='stylesheet' id='animate-css-css'  href='css/animate.css/animate.min.css?ver=4.3.1' type='text/css' media='all' />
        <link rel='stylesheet' id='font-awesome-css'  href='css/font-awesome.min.css?ver=4.6.1' type='text/css' media='screen' />
        <link rel='stylesheet' id='themify-icons-css'  href='css/themify-icons.css?ver=4.3.1' type='text/css' media='all' />
        <link rel='stylesheet' id='azexo-style-css'  href='css/style.css?ver=4.3.1' type='text/css' media='all' />
        <link rel='stylesheet' id='azexo-css'  href='css/azexo-07c6e42dd7.css' type='text/css' media='all' />
        <link rel='stylesheet' id='select2-css'  href='css/select2.css?ver=4.3.1' type='text/css' media='all' />
        <link rel='stylesheet' id='vc_linecons-css'  href='css/vc_linecons_icons.css?ver=4.6.1' type='text/css' media='screen' />
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/jquery.js?ver=1.11.3'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.2.1'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/azexo_vc_elements/js/azexo_vc.js?ver=4.3.1'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/azexo_vc_elements/js/scrollReveal.min.js?ver=4.3.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/kupon2\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kupon2\/contact\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View Cart","cart_url":"http:\/\/azexo.com\/kupon2\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=2.4.8'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=4.6.1'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/woocommerce-pdf-vouchers/includes/js/woo-vou-public.js?ver=2.4.5'></script>
<script type='text/javascript' src='css/js/jquery.fitvids.js?ver=1'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://azexo.com/kupon2/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://azexo.com/kupon2/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.3.1" />
<meta name="generator" content="WooCommerce 2.4.8" />
<link rel='canonical' href='http://azexo.com/kupon2/contact/' />
<link rel='shortlink' href='http://azexo.com/kupon2/?p=68' />
<style type="text/css">                    #header{
margin: 0 auto;
}                </style><!--CUSTOM STYLE--><style type="text/css"></style><!--/CUSTOM STYLE--><meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/css/vc-ie8.css" media="screen"><![endif]--><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>    </head>

<?php
    
    include('Header.php');
    
    // should the html code before this php be deleted?
    
    ?>



<div id="main" class="site-main">

<div class="container active-sidebar">
    <div id="primary" class="content-area">
    
    <header class="page-header">
        <h1 class="page-title">
            Contact        </h1>
            </header>
        <div id="content" class="site-content" role="main">
                            <div id="post-68" class="entry post-68 page type-page status-publish hentry">
                    <div class="entry-content">
                        <div class="vc_row wpb_row vc_row-fluid"><div class="row"><div class="h-padding-0 wpb_column vc_column_container vc_col-sm-12"><div class="wpb_wrapper"><div class="wpb_gmaps_widget wpb_content_element">
		<div class="wpb_wrapper">
		<div class="wpb_map_wraper">
			<iframe width="100%" height="standard" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d180923.20573680187!2d18.431035300000026!3d44.88417339999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x475c3ce74d1a2ad7%3A0xec92baaa82e344b0!2zR3JhZGHEjWFj!5e0!3m2!1sen!2sba!4v1430647606971&amp;t=m&amp;z=14&amp;output=embed"></iframe>		</div>
	</div>
</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h4>Your data will be safe!</h4>
<p>Your email address will not be published. Required fields are marked *</p>

		</div>
	</div> <div role="form" class="wpcf7" id="wpcf7-f69-p68-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="/kupon2/contact/#wpcf7-f69-p68-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="69" />
<input type="hidden" name="_wpcf7_version" value="4.3" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f69-p68-o1" />
<input type="hidden" name="_wpnonce" value="f6d941e0c4" />
</div>
<p>Your Name (required)<br />
    <span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" /></span> </p>
<p>Your Email (required)<br />
    <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" /></span> </p>
<p>Subject<br />
    <span class="wpcf7-form-control-wrap your-subject"><input type="text" name="your-subject" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" /></span> </p>
<p>Your Message<br />
    <span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span> </p>
<p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit" /></p>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div></div></div></div>
                                            </div><!-- .entry-content -->
                </div><!-- #post -->
                                    </div><!-- #content -->
    </div><!-- #primary -->
 








</div><!-- #page -->

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter30702498 = new Ya.Metrika({id:30702498,
                    webvisor:true,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true});
        } catch(e) { }
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/30702498" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter --><script type="text/javascript">                    jQuery(document).ready(function(){

});                </script><script type='text/javascript' src='css/js/azwoo.js?ver=1.12'></script>
<script type='text/javascript' src='css/js/jquery.countdown.min.js?ver=1.12'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_var = {"url":"http:\/\/azexo.com\/kupon2\/wp-admin\/admin-ajax.php","nonce":"d3c88ba798"};
/* ]]> */
</script>
<script type='text/javascript' src='css/post-like-system/js/post-like.min.js?ver=1.0'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/wc_deals/js/azwoo_deals.js?ver=4.3.1'></script>
<script type='text/javascript' src='js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/azexo.com\/kupon2\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"Sending ...","cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='js/scripts.js?ver=4.3'></script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/kupon2\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kupon2\/contact\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=2.4.8'></script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/jquery-cookie/jquery.cookie.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/kupon2\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/kupon2\/contact\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments"};
/* ]]> */
</script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=2.4.8'></script>
<script type='text/javascript' src='css/js/azexo.js?ver=1.12'></script>
<script type='text/javascript' src='css/js/jquery.sticky-kit.min.js?ver=1.12'></script>
<script type='text/javascript' src='css/js/imagesloaded.pkgd.min.js?ver=1.12'></script>
<script type='text/javascript' src='css/js/background-check.min.js?ver=1.12'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/js/js_composer_front.js?ver=4.6.1'></script>
<script type='text/javascript' src='//azexo.com/kupon2/wp-content/plugins/woocommerce/assets/js/select2/select2.min.js?ver=3.5.2'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-includes/js/jquery/ui/tabs.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://azexo.com/kupon2/wp-content/plugins/js_composer/assets/lib/bower/jquery-ui-tabs-rotate/jquery-ui-tabs-rotate.js?ver=4.6.1'></script>
</body>
</html>
