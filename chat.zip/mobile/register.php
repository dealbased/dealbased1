<?php
    session_start();
    $submit  = $_POST['submit'];
    $_SESSION['firstname'] = $firstname = strip_tags ($_POST ['firstname']);
    $lastname = strip_tags ($_POST ['lastname']);
    
    $emailaddress = strtolower(strip_tags ($_POST ['emailaddress']));
    $password = strip_tags ($_POST ['password']);
    $repeatpassword = strip_tags ($_POST ['repeatpassword']);
    $date = date ("Y-m-d");
    
    $_SESSION['systemMessageReg']='';
    $_SESSION['systemMessageRegSuccess']='';
    
    
    if($submit)
    
    {
        
        $connect = mysql_connect("localhost","credqglo_users","Qq03049835") or die ("Couldn't connect!");
        mysql_select_db("credqglo_users") or die ("Couldn't Find DB!"); // check if user already exist
        
        $namecheck = mysql_query ("select emailaddress from users where emailaddress = '$emailaddress' ");
        $count = mysql_num_rows($namecheck);
        
        if ($count!=0)
        {
            $_SESSION['systemMessageReg'] = "emailaddress already taken";
        }
        
        if($firstname   && $lastname && $password && $emailaddress && $repeatpassword)
        {
            
            if ($password == $repeatpassword)
            {
                
                if (strlen ($emailaddress) >25 || strlen ($firstname)>25 || strlen ($lastname)>25)
                {
                    $_SESSION['systemMessageReg'] = "Its too long it won't fit into our Database :( Max 25 Character!";
                }
                
                else
                {
                    if (strlen($password)>25||strlen($password)<6)
                    {
                        $_SESSION['systemMessageReg'] = "Password must be between 6 and 25 characters!";
                    }
                    else
                        $password = md5 ($password);
                    $repeatpassword = md5 ($repeatpassword);
                    
                    $connect = mysql_connect("localhost","credqglo_users","Qq03049835") or die ("Couldn't connect!");
                    mysql_select_db("credqglo_users") or die ("Couldn't Find DB!");
                    $queryreg = mysql_query("
                                            INSERT INTO users VALUES ('$emailaddress','$firstname','$lastname','$date','$password','')
                                            ");
                                            
                                            }
                                            $_SESSION['systemMessageRegSuccess'] = "Welcome $firstname, you can Log in now";
                                            
                                            }
                                            
                                            
                                            
                                            else $_SESSION['systemMessageReg'] = "Your Password don't match";
                                            }
                                            
                                            else $_SESSION['systemMessageReg'] = " Please fill in all fields";
                                            
                                            }
                                            
                                            // https://www.youtube.com/watch?v=JhLnS0mXr0M
                                            
                                            header("Location: RegisterLogin.php");

